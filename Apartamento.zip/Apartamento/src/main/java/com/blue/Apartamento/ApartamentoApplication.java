package com.blue.Apartamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApartamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApartamentoApplication.class, args);
	}

}
