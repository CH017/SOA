package com.blue.Apartamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApartamentoApplicationTests {

	@Test
	void contextLoads() {
	}

}
